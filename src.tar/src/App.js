import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Link, useParams } from "react-router-dom";
import { useState } from "react";
import "./App.css";

const products = [
  { id: 1, name: "Lamborghini Aventador", image: "/images/product2.jpg", price: 65000000000, description: "Lamborghini Aventador sở hữu động cơ V12 mạnh mẽ, thiết kế khí động học sắc sảo, khả năng tăng tốc 0-100 km/h chỉ trong 2.9 giây và nội thất xa hoa bậc nhất." },
  { id: 2, name: "BMW i10", image: "/images/product1.jpg", price: 5000000000, description: "BMW i10 là mẫu xe đô thị nhỏ gọn, tiết kiệm nhiên liệu, nội thất hiện đại với nhiều công nghệ tiên tiến, mang lại trải nghiệm lái thoải mái và tiện lợi." },
  { id: 3, name: "McLaren 720S", image: "/images/product3.jpg", price: 7000000000, description: "McLaren 720S được trang bị động cơ V8 tăng áp kép, công suất lên đến 710 mã lực, hệ thống khung gầm siêu nhẹ và thiết kế đậm chất thể thao, mang lại hiệu suất đỉnh cao." },
];


function ProductList({ addToCart }) {
  return (
    <div>
      <h1>Danh sách sản phẩm</h1>
      <Link to="/cart" className="cart-button">Giỏ hàng</Link>
      <div className="product-list">
        {products.map((product) => (
          <div key={product.id} className="product-item">
            <img src={product.image} alt={product.name} width="100" />
            <div className="product-info">
              <h3>{product.name} - {product.price} VND</h3>
              <Link to={`/product/${product.id}`}><button>Xem chi tiết</button></Link>
              <button onClick={() => addToCart(product)}>Thêm vào giỏ</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ProductDetail({ addToCart }) {
  const { id } = useParams();
  const product = products.find((p) => p.id === parseInt(id));

  return (
    <div className="product-detail-container">
      <div className="product-detail-card">
        <img src={product.image} alt={product.name} className="product-detail-image" />
        <div className="product-detail-info">
          <h1>{product.name}</h1>
          <p className="product-price"><strong>Giá:</strong> {product.price.toLocaleString()} VND</p>
          <p className="product-description"><strong>Mô tả:</strong> {product.description}</p>
          <button onClick={() => addToCart(product)}>Thêm vào giỏ</button>
          <Link to="/" className="back-button">⬅ Quay lại danh sách</Link>
        </div>
      </div>
    </div>
  );
}


function Cart({ cart, removeFromCart }) {
  return (
    <div>
      <h1>Giỏ hàng</h1>
      {cart.length === 0 ? (
        <p>Giỏ hàng trống</p>
      ) : (
        cart.map((item, index) => (
          <div key={index} className="cart-item">
            <img src={item.image} alt={item.name} width="100" />
            <p>{item.name} - {item.price} VND</p>
            <button onClick={() => removeFromCart(index)}>🗑 Xóa</button>
            <button className="buy-button">🛒 Mua</button>
          </div>
        ))
      )}
      <br />
      <Link to="/"className="back-button">Quay lại danh sách</Link>
    </div>
  );
}

export default function App() {
  const [cart, setCart] = useState([]);
  const [message, setMessage] = useState(""); // Trạng thái cho thông báo

  const addToCart = (product) => {
    setCart([...cart, product]);
    setMessage(`${product.name} đã được thêm vào giỏ hàng!`);

    // Tự động ẩn thông báo sau 2 giây
    setTimeout(() => {
      setMessage("");
    }, 2000);
  };

  const removeFromCart = (index) => {
    setCart(cart.filter((_, i) => i !== index));
  };

  return (
    <Router>
      <div className="notification-container">
        {message && <div className="notification">{message}</div>}
      </div>
      <Routes>
        <Route path="/" element={<ProductList addToCart={addToCart} />} />
        <Route path="/product/:id" element={<ProductDetail addToCart={addToCart} />} />
        <Route path="/cart" element={<Cart cart={cart} removeFromCart={removeFromCart} />} />
      </Routes>
    </Router>
  );
}
